/**
 * 
 */
package no.hvl.dat109.stigespill;

/**
 * Klasse som representerer en rute
 * 
 * @author Julie Marie Heldal og Vilde Kristine Fossum
 *
 */
public class Rute {
	
	private Integer ruteNr;
	private Slanger slange;
	private Stiger stige;
	
	
	public Integer getRuteNr() {
		return this.ruteNr;
	}


	public void setRuteNr(int ruteNr) {
		this.ruteNr = ruteNr;
	}
	
	public Slanger getSlange() {
		return this.slange;
	}
	
	public Stiger getStige() {
		return this.stige;
	}

	
	

}
