/**
 * 
 */
package no.hvl.dat109.stigespill;

/**
 * @author Julie Marie Heldal
 *
 *Definerer en klasse hvor man kjører spillet fra. 
 */
public class Main {
	
	public static void main(String[] args) {
		
		Stigespill stigespill = new Stigespill();
		stigespill.startSpill();
		
	}

}

