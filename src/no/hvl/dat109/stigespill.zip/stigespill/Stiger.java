/**
 * 
 */
package no.hvl.dat109.stigespill;



/**
 * @author Julie Heldal og Vilde Fossum
 *
 * Definerer en klasse med Stiger
 */

public class Stiger {
	
private int lengde;
	/**
	 * Oppretter et nytt stigeobjekt
	 */
	public Stiger() {
		this.lengde = 0;
	}

	public int getLengde() {
		return lengde;
	}

	public void setLengde(int lengde) {
		this.lengde = lengde;
	}
	
	
	
	
	

}
