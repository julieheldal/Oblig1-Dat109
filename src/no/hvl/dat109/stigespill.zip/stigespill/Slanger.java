/**
 * 
 */
package no.hvl.dat109.stigespill;

/**
 * @author juliemarieschnellheldal
 * Definerer en klasse med Slanger
 */
public class Slanger {
	
private int lengde;
	
	public Slanger() {
		this.lengde = 0;
	}

	public int getLengde() {
		return lengde;
	}

	public void setLengde(int lengde) {
		this.lengde = lengde;
	}
	

}
