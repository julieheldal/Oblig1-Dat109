package no.hvl.dat109.stigespill;

public enum Farge { 
	BLÅ, RØD, GRØNN, GUL
}
